(self["webpackChunkaem_maven_archetype"] = self["webpackChunkaem_maven_archetype"] || []).push([["main-webpack-components-cardgroup-doc-cardgroup-stories"],{

/***/ "./src/main/webpack/components/cardgroup/cardgroup.hbs":
/*!*************************************************************!*\
  !*** ./src/main/webpack/components/cardgroup/cardgroup.hbs ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<div class=\"cardgroup\">\n    <div class=\"aem-Grid aem-Grid--12\">\n        <div class=\"aem-GridColumn aem-GridColumn--default--4 aem-GridColumn--phone--12 aem-GridColumn--tablet--6\">\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"TeaserWithImage"),depth0,{"name":"TeaserWithImage","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "        </div>\n        <div class=\"aem-GridColumn aem-GridColumn--default--4 aem-GridColumn--phone--12 aem-GridColumn--tablet--6\">\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"TeaserWithImage"),depth0,{"name":"TeaserWithImage","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "        </div>\n        <div class=\"aem-GridColumn aem-GridColumn--default--4 aem-GridColumn--phone--12 aem-GridColumn--tablet--6\">\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"TeaserWithImage"),depth0,{"name":"TeaserWithImage","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "        </div>\n    </div>\n</div>";
},"usePartial":true,"useData":true});

/***/ }),

/***/ "./src/main/webpack/components/cardgroup/doc/cardgroup.json":
/*!******************************************************************!*\
  !*** ./src/main/webpack/components/cardgroup/doc/cardgroup.json ***!
  \******************************************************************/
/***/ (function(module) {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('{"variation":"primary","copy":"&copy;2022 Adobe Systems Inc.","content":"Footer"}');

/***/ }),

/***/ "./src/main/webpack/components/cardgroup/doc/cardgroup.stories.js":
/*!************************************************************************!*\
  !*** ./src/main/webpack/components/cardgroup/doc/cardgroup.stories.js ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Primary: function() { return /* binding */ Primary; }
/* harmony export */ });
/* harmony import */ var handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
/* harmony import */ var handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _cardgroup_hbs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../cardgroup.hbs */ "./src/main/webpack/components/cardgroup/cardgroup.hbs");
/* harmony import */ var _cardgroup_hbs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_cardgroup_hbs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _cardgroup_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cardgroup.json */ "./src/main/webpack/components/cardgroup/doc/cardgroup.json");
/* harmony import */ var _core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core-components/teaser/with-image.hbs */ "./src/main/webpack/core-components/teaser/with-image.hbs");
/* harmony import */ var _core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_3__);
function _objectDestructuringEmpty(t) {
  if (null == t) throw new TypeError("Cannot destructure " + t);
}
function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function (n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}




handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('TeaserWithImage', (_core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_3___default()));
/* harmony default export */ __webpack_exports__["default"] = ({
  title: "Components/CardGroup",
  argTypes: {
    variation: {
      control: {
        type: "select",
        options: ["primary", "secondary"]
      }
    },
    content: {
      control: {
        type: "text"
      }
    }
  },
  parameters: {
    docs: {
      source: {
        code: "".concat(JSON.stringify(_cardgroup_json__WEBPACK_IMPORTED_MODULE_2__))
      }
    }
  }
});
var Template = function Template(_ref) {
  var args = _extends({}, (_objectDestructuringEmpty(_ref), _ref));
  return _cardgroup_hbs__WEBPACK_IMPORTED_MODULE_1___default()(args);
};
var Primary = Template.bind({});
Primary.args = _cardgroup_json__WEBPACK_IMPORTED_MODULE_2__;
Primary.parameters = {
  docs: {
    source: {
      code: "".concat(JSON.stringify(_cardgroup_json__WEBPACK_IMPORTED_MODULE_2__, null, " "))
    }
  },
  tags: ['visual']
};

// export const Primary = (args, { loaded }) => `${JSON.stringify(loaded, null, 1)} ${Object.keys(loaded).map((key) => loaded[key] )}`;
// Primary.loaders = [async () => await render({ name: "Alex" })];;export const __namedExportsOrder = ["Primary"];
Primary.parameters = {
  ...Primary.parameters,
  docs: {
    ...Primary.parameters?.docs,
    source: {
      originalSource: "({\n  ...args\n}) => CardGroup(args)",
      ...Primary.parameters?.docs?.source
    }
  }
};

/***/ }),

/***/ "./src/main/webpack/core-components/teaser/with-image.hbs":
/*!****************************************************************!*\
  !*** ./src/main/webpack/core-components/teaser/with-image.hbs ***!
  \****************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class=\"teaser\">\n  <div\n    id=\"teaser-66129ff9d4\"\n    class=\"cmp-teaser\"\n    data-cmp-data-layer=\"{&quot;teaser-66129ff9d4&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/teaser&quot;,&quot;dc:title&quot;:&quot;Teaser Title&quot;,&quot;dc:description&quot;:&quot;<p>Teaser Description</p>&quot;}}\"\n  >\n    <div class=\"cmp-teaser__content\">\n      <p class=\"cmp-teaser__pretitle\">Pretitle</p>\n      <h2 class=\"cmp-teaser__title\"> Teaser Title </h2>\n      <div class=\"cmp-teaser__description\">\n        <p>Teaser Description</p>\n      </div>\n    </div>\n    <div class=\"cmp-teaser__image\">\n      <div\n        data-asset-id=\"0f54e1b5-535b-45f7-a46b-35abb19dd6bc\"\n        id=\"image-66129ff9d4\"\n        data-cmp-data-layer=\"{&quot;image-66129ff9d4&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/image&quot;,&quot;dc:title&quot;:&quot;Lava flowing into the ocean&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser.html&quot;,&quot;image&quot;:{&quot;repo:id&quot;:&quot;0f54e1b5-535b-45f7-a46b-35abb19dd6bc&quot;,&quot;repo:modifyDate&quot;:&quot;1970-01-01T00:00:00Z&quot;,&quot;@type&quot;:&quot;image/jpeg&quot;,&quot;repo:path&quot;:&quot;https://www.aemcomponents.dev/content/dam/core-components-examples/library/sample-assets/lava-into-ocean.jpg&quot;}}}\"\n        class=\"cmp-image\"\n        itemscope=\"\"\n        itemtype=\"http://schema.org/ImageObject\"\n      >\n        <img\n          srcset=\"https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.600.jpeg 600w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.800.jpeg 800w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.1000.jpeg 1000w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.1200.jpeg 1200w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.1600.jpeg 1600w\"\n          src=\"https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.jpeg\"\n          loading=\"lazy\"\n          class=\"cmp-image__image\"\n          itemprop=\"contentUrl\"\n          width=\"850\"\n          height=\"509\"\n          alt=\"Lava flowing into the ocean\"\n          title=\"Lava flowing into the ocean\"\n        />\n        <meta itemprop=\"caption\" content=\"Lava flowing into the ocean\" />\n      </div>\n    </div>\n  </div>\n</div>";
},"useData":true});

/***/ })

}]);
//# sourceMappingURL=main-webpack-components-cardgroup-doc-cardgroup-stories.iframe.bundle.js.map