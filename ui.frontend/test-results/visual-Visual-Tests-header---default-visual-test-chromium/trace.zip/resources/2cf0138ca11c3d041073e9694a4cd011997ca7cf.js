(self["webpackChunkaem_maven_archetype"] = self["webpackChunkaem_maven_archetype"] || []).push([["main-webpack-components-header-doc-header-stories"],{

/***/ "./src/main/webpack/components/header/doc/header.stories.js":
/*!******************************************************************!*\
  !*** ./src/main/webpack/components/header/doc/header.stories.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Default: function() { return /* binding */ Default; },
/* harmony export */   Header: function() { return /* reexport default from dynamic */ _header_hbs__WEBPACK_IMPORTED_MODULE_0___default.a; },
/* harmony export */   __namedExportsOrder: function() { return /* binding */ __namedExportsOrder; }
/* harmony export */ });
/* harmony import */ var _header_hbs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../header.hbs */ "./src/main/webpack/components/header/header.hbs");
/* harmony import */ var _header_hbs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_header_hbs__WEBPACK_IMPORTED_MODULE_0__);
function _objectDestructuringEmpty(t) {
  if (null == t) throw new TypeError("Cannot destructure " + t);
}
function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function (n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}

/* harmony default export */ __webpack_exports__["default"] = ({
  title: "Components/Header",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {
    title: {
      control: 'text',
      description: 'Header title text'
    }
  }
});

// Create a template for the header
var Template = function Template(_ref) {
  var args = _extends({}, (_objectDestructuringEmpty(_ref), _ref));
  return _header_hbs__WEBPACK_IMPORTED_MODULE_0___default()(args);
};

// Create the default story
var Default = Template.bind({});
Default.args = {
  title: 'Default Header'
};
Default.parameters = {
  tags: ['visual'] // Add visual tag to enable visual testing
};

;
const __namedExportsOrder = ["Default", "Header"];
Default.parameters = {
  ...Default.parameters,
  docs: {
    ...Default.parameters?.docs,
    source: {
      originalSource: "({\n  ...args\n}) => Header(args)",
      ...Default.parameters?.docs?.source
    }
  }
};

/***/ }),

/***/ "./src/main/webpack/components/header/header.hbs":
/*!*******************************************************!*\
  !*** ./src/main/webpack/components/header/header.hbs ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<header class=\"header\" data-component=\"header\">\n    <div class=\"container\">\n       <a href=\"#\"><img src=\"images/logo.png\"></a>\n       <span class=\"header__title\">Header</span>\n    </div>\n</header>\n";
},"useData":true});

/***/ })

}]);
//# sourceMappingURL=main-webpack-components-header-doc-header-stories.iframe.bundle.js.map