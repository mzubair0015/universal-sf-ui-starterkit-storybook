(self["webpackChunkaem_maven_archetype"] = self["webpackChunkaem_maven_archetype"] || []).push([["main-webpack-components-footer-doc-footer-stories"],{

/***/ "./src/main/webpack/components/footer/doc/footer.json":
/*!************************************************************!*\
  !*** ./src/main/webpack/components/footer/doc/footer.json ***!
  \************************************************************/
/***/ (function(module) {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('{"variation":"primary","copy":"Copyright 2022 Adobe Systems Inc.","content":"Footer"}');

/***/ }),

/***/ "./src/main/webpack/components/footer/doc/footer.stories.js":
/*!******************************************************************!*\
  !*** ./src/main/webpack/components/footer/doc/footer.stories.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Primary: function() { return /* binding */ Primary; }
/* harmony export */ });
/* harmony import */ var _footer_hbs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../footer.hbs */ "./src/main/webpack/components/footer/footer.hbs");
/* harmony import */ var _footer_hbs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_footer_hbs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _footer_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./footer.json */ "./src/main/webpack/components/footer/doc/footer.json");
function _objectDestructuringEmpty(t) {
  if (null == t) throw new TypeError("Cannot destructure " + t);
}
function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function (n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}


/* harmony default export */ __webpack_exports__["default"] = ({
  title: "Components/Footer",
  argTypes: {
    variation: {
      control: {
        type: "select",
        options: ["primary", "secondary"]
      }
    },
    content: {
      control: {
        type: "text"
      }
    }
  },
  parameters: {
    docs: {
      source: {
        code: "".concat(JSON.stringify(_footer_json__WEBPACK_IMPORTED_MODULE_1__))
      }
    }
  }
});
var Template = function Template(_ref) {
  var args = _extends({}, (_objectDestructuringEmpty(_ref), _ref));
  return _footer_hbs__WEBPACK_IMPORTED_MODULE_0___default()(args);
};
var Primary = Template.bind({});
Primary.args = _footer_json__WEBPACK_IMPORTED_MODULE_1__;
Primary.parameters = {
  docs: {
    source: {
      code: "".concat(JSON.stringify(_footer_json__WEBPACK_IMPORTED_MODULE_1__, null, " "))
    }
  },
  tags: ['visual']
};

// export const Primary = (args, { loaded }) => `${JSON.stringify(loaded, null, 1)} ${Object.keys(loaded).map((key) => loaded[key] )}`;
// Primary.loaders = [async () => await render({ name: "Alex" })];;export const __namedExportsOrder = ["Primary"];
Primary.parameters = {
  ...Primary.parameters,
  docs: {
    ...Primary.parameters?.docs,
    source: {
      originalSource: "({\n  ...args\n}) => Footer(args)",
      ...Primary.parameters?.docs?.source
    }
  }
};

/***/ }),

/***/ "./src/main/webpack/components/footer/footer.hbs":
/*!*******************************************************!*\
  !*** ./src/main/webpack/components/footer/footer.hbs ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"1":function(container,depth0,helpers,partials,data) {
    var helper, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "footer--"
    + container.escapeExpression(((helper = (helper = lookupProperty(helpers,"variation") || (depth0 != null ? lookupProperty(depth0,"variation") : depth0)) != null ? helper : container.hooks.helperMissing),(typeof helper === "function" ? helper.call(depth0 != null ? depth0 : (container.nullContext || {}),{"name":"variation","hash":{},"data":data,"loc":{"start":{"line":1,"column":47},"end":{"line":1,"column":60}}}) : helper)));
},"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=container.hooks.helperMissing, alias3="function", alias4=container.escapeExpression, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<footer class=\"footer "
    + ((stack1 = lookupProperty(helpers,"if").call(alias1,(depth0 != null ? lookupProperty(depth0,"variation") : depth0),{"name":"if","hash":{},"fn":container.program(1, data, 0),"inverse":container.noop,"data":data,"loc":{"start":{"line":1,"column":22},"end":{"line":1,"column":67}}})) != null ? stack1 : "")
    + "\" data-component=\"footer\">\n    <div class=\"container\">\n		<!--Footer Main-->\n		<span>"
    + alias4(((helper = (helper = lookupProperty(helpers,"copy") || (depth0 != null ? lookupProperty(depth0,"copy") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"copy","hash":{},"data":data,"loc":{"start":{"line":4,"column":8},"end":{"line":4,"column":16}}}) : helper)))
    + "</span>\n		<span>"
    + alias4(((helper = (helper = lookupProperty(helpers,"content") || (depth0 != null ? lookupProperty(depth0,"content") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"content","hash":{},"data":data,"loc":{"start":{"line":5,"column":8},"end":{"line":5,"column":19}}}) : helper)))
    + "</span>\n	</div>\n	<div>\n		\n	</div>\n</footer>";
},"useData":true});

/***/ })

}]);
//# sourceMappingURL=main-webpack-components-footer-doc-footer-stories.iframe.bundle.js.map