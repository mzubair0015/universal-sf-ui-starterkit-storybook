(self["webpackChunkaem_maven_archetype"] = self["webpackChunkaem_maven_archetype"] || []).push([["main-webpack-pages-home-doc-home-stories"],{

/***/ "./src/main/webpack/components/cardgroup/cardgroup.hbs":
/*!*************************************************************!*\
  !*** ./src/main/webpack/components/cardgroup/cardgroup.hbs ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<div class=\"cardgroup\">\n    <div class=\"aem-Grid aem-Grid--12\">\n        <div class=\"aem-GridColumn aem-GridColumn--default--4 aem-GridColumn--phone--12 aem-GridColumn--tablet--6\">\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"TeaserWithImage"),depth0,{"name":"TeaserWithImage","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "        </div>\n        <div class=\"aem-GridColumn aem-GridColumn--default--4 aem-GridColumn--phone--12 aem-GridColumn--tablet--6\">\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"TeaserWithImage"),depth0,{"name":"TeaserWithImage","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "        </div>\n        <div class=\"aem-GridColumn aem-GridColumn--default--4 aem-GridColumn--phone--12 aem-GridColumn--tablet--6\">\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"TeaserWithImage"),depth0,{"name":"TeaserWithImage","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "        </div>\n    </div>\n</div>";
},"usePartial":true,"useData":true});

/***/ }),

/***/ "./src/main/webpack/components/footer/footer.hbs":
/*!*******************************************************!*\
  !*** ./src/main/webpack/components/footer/footer.hbs ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"1":function(container,depth0,helpers,partials,data) {
    var helper, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "footer--"
    + container.escapeExpression(((helper = (helper = lookupProperty(helpers,"variation") || (depth0 != null ? lookupProperty(depth0,"variation") : depth0)) != null ? helper : container.hooks.helperMissing),(typeof helper === "function" ? helper.call(depth0 != null ? depth0 : (container.nullContext || {}),{"name":"variation","hash":{},"data":data,"loc":{"start":{"line":1,"column":47},"end":{"line":1,"column":60}}}) : helper)));
},"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=container.hooks.helperMissing, alias3="function", alias4=container.escapeExpression, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<footer class=\"footer "
    + ((stack1 = lookupProperty(helpers,"if").call(alias1,(depth0 != null ? lookupProperty(depth0,"variation") : depth0),{"name":"if","hash":{},"fn":container.program(1, data, 0),"inverse":container.noop,"data":data,"loc":{"start":{"line":1,"column":22},"end":{"line":1,"column":67}}})) != null ? stack1 : "")
    + "\" data-component=\"footer\">\n    <div class=\"container\">\n		<!--Footer Main-->\n		<span>"
    + alias4(((helper = (helper = lookupProperty(helpers,"copy") || (depth0 != null ? lookupProperty(depth0,"copy") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"copy","hash":{},"data":data,"loc":{"start":{"line":4,"column":8},"end":{"line":4,"column":16}}}) : helper)))
    + "</span>\n		<span>"
    + alias4(((helper = (helper = lookupProperty(helpers,"content") || (depth0 != null ? lookupProperty(depth0,"content") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"content","hash":{},"data":data,"loc":{"start":{"line":5,"column":8},"end":{"line":5,"column":19}}}) : helper)))
    + "</span>\n	</div>\n	<div>\n		\n	</div>\n</footer>";
},"useData":true});

/***/ }),

/***/ "./src/main/webpack/components/header/header.hbs":
/*!*******************************************************!*\
  !*** ./src/main/webpack/components/header/header.hbs ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<header class=\"header\" data-component=\"header\">\n    <div class=\"container\">\n       <a href=\"#\"><img src=\"images/logo.png\"></a>\n       <span class=\"header__title\">Header</span>\n    </div>\n</header>\n";
},"useData":true});

/***/ }),

/***/ "./src/main/webpack/core-components/breadcrumb/standard.hbs":
/*!******************************************************************!*\
  !*** ./src/main/webpack/core-components/breadcrumb/standard.hbs ***!
  \******************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class=\"breadcrumb\">\n  <nav id=\"breadcrumb-480245d3af\" class=\"cmp-breadcrumb\" aria-label=\"Breadcrumb\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb&quot;}}\">\n    <ol class=\"cmp-breadcrumb__list\" itemscope=\"\" itemtype=\"http://schema.org/BreadcrumbList\">\n      <li class=\"cmp-breadcrumb__item\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af-item-9bee4d4454&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb/item&quot;,&quot;repo:modifyDate&quot;:&quot;2019-12-20T18:35:24Z&quot;,&quot;dc:title&quot;:&quot;Component Library&quot;,&quot;xdm:linkURL&quot;:&quot;/content/core-components-examples/library.html&quot;}}\" itemprop=\"itemListElement\" itemscope=\"\" itemtype=\"http://schema.org/ListItem\">\n        <a class=\"cmp-breadcrumb__item-link\" itemprop=\"item\" data-cmp-clickable=\"\" href=\"/content/core-components-examples/library.html\">\n          <span itemprop=\"name\">Component Library</span>\n        </a>\n        <meta itemprop=\"position\" content=\"1\">\n      </li>\n      <li class=\"cmp-breadcrumb__item\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af-item-3a0f66ac7b&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb/item&quot;,&quot;dc:title&quot;:&quot;Component Library&quot;,&quot;xdm:linkURL&quot;:&quot;/content/core-components-examples/library.html&quot;}}\" itemprop=\"itemListElement\" itemscope=\"\" itemtype=\"http://schema.org/ListItem\">\n        <a class=\"cmp-breadcrumb__item-link\" itemprop=\"item\" data-cmp-clickable=\"\" href=\"/content/core-components-examples/library.html\">\n          <span itemprop=\"name\">Component Library</span>\n        </a>\n        <meta itemprop=\"position\" content=\"2\">\n      </li>\n      <li class=\"cmp-breadcrumb__item\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af-item-7080538dd6&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb/item&quot;,&quot;dc:title&quot;:&quot;Breadcrumb&quot;,&quot;xdm:linkURL&quot;:&quot;/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1/level-2/breadcrumb.html&quot;}}\" itemprop=\"itemListElement\" itemscope=\"\" itemtype=\"http://schema.org/ListItem\">\n        <a class=\"cmp-breadcrumb__item-link\" itemprop=\"item\" data-cmp-clickable=\"\" href=\"/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1/level-2/breadcrumb.html\">\n          <span itemprop=\"name\">Breadcrumb</span>\n        </a>\n        <meta itemprop=\"position\" content=\"3\">\n      </li>\n      <li class=\"cmp-breadcrumb__item\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af-item-2ae1704812&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb/item&quot;,&quot;repo:modifyDate&quot;:&quot;2022-03-08T10:11:15Z&quot;,&quot;dc:title&quot;:&quot;Level 1&quot;,&quot;xdm:linkURL&quot;:&quot;/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1.html&quot;}}\" itemprop=\"itemListElement\" itemscope=\"\" itemtype=\"http://schema.org/ListItem\">\n        <a class=\"cmp-breadcrumb__item-link\" itemprop=\"item\" data-cmp-clickable=\"\" href=\"/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1.html\">\n          <span itemprop=\"name\">Level 1</span>\n        </a>\n        <meta itemprop=\"position\" content=\"4\">\n      </li>\n      <li class=\"cmp-breadcrumb__item\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af-item-17eadd49ba&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb/item&quot;,&quot;repo:modifyDate&quot;:&quot;2022-03-08T10:11:15Z&quot;,&quot;dc:title&quot;:&quot;Level 2&quot;,&quot;xdm:linkURL&quot;:&quot;/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1/level-2.html&quot;}}\" itemprop=\"itemListElement\" itemscope=\"\" itemtype=\"http://schema.org/ListItem\">\n        <a class=\"cmp-breadcrumb__item-link\" itemprop=\"item\" data-cmp-clickable=\"\" href=\"/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1/level-2.html\">\n          <span itemprop=\"name\">Level 2</span>\n        </a>\n        <meta itemprop=\"position\" content=\"5\">\n      </li>\n      <li class=\"cmp-breadcrumb__item cmp-breadcrumb__item--active\" aria-current=\"page\" data-cmp-data-layer=\"{&quot;breadcrumb-480245d3af-item-ab50f79f36&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/breadcrumb/item&quot;,&quot;repo:modifyDate&quot;:&quot;2022-03-08T10:11:15Z&quot;,&quot;dc:title&quot;:&quot;Breadcrumb&quot;,&quot;xdm:linkURL&quot;:&quot;/content/core-components-examples/library/core-structure/breadcrumb/hidden/level-1/level-2/breadcrumb.html&quot;}}\" itemprop=\"itemListElement\" itemscope=\"\" itemtype=\"http://schema.org/ListItem\">\n        <span itemprop=\"name\">Breadcrumb</span>\n        <meta itemprop=\"position\" content=\"6\">\n      </li>\n    </ol>\n  </nav>\n</div>\n\n";
},"useData":true});

/***/ }),

/***/ "./src/main/webpack/core-components/teaser/with-image.hbs":
/*!****************************************************************!*\
  !*** ./src/main/webpack/core-components/teaser/with-image.hbs ***!
  \****************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class=\"teaser\">\n  <div\n    id=\"teaser-66129ff9d4\"\n    class=\"cmp-teaser\"\n    data-cmp-data-layer=\"{&quot;teaser-66129ff9d4&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/teaser&quot;,&quot;dc:title&quot;:&quot;Teaser Title&quot;,&quot;dc:description&quot;:&quot;<p>Teaser Description</p>&quot;}}\"\n  >\n    <div class=\"cmp-teaser__content\">\n      <p class=\"cmp-teaser__pretitle\">Pretitle</p>\n      <h2 class=\"cmp-teaser__title\"> Teaser Title </h2>\n      <div class=\"cmp-teaser__description\">\n        <p>Teaser Description</p>\n      </div>\n    </div>\n    <div class=\"cmp-teaser__image\">\n      <div\n        data-asset-id=\"0f54e1b5-535b-45f7-a46b-35abb19dd6bc\"\n        id=\"image-66129ff9d4\"\n        data-cmp-data-layer=\"{&quot;image-66129ff9d4&quot;:{&quot;@type&quot;:&quot;core-components-examples/components/image&quot;,&quot;dc:title&quot;:&quot;Lava flowing into the ocean&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser.html&quot;,&quot;image&quot;:{&quot;repo:id&quot;:&quot;0f54e1b5-535b-45f7-a46b-35abb19dd6bc&quot;,&quot;repo:modifyDate&quot;:&quot;1970-01-01T00:00:00Z&quot;,&quot;@type&quot;:&quot;image/jpeg&quot;,&quot;repo:path&quot;:&quot;https://www.aemcomponents.dev/content/dam/core-components-examples/library/sample-assets/lava-into-ocean.jpg&quot;}}}\"\n        class=\"cmp-image\"\n        itemscope=\"\"\n        itemtype=\"http://schema.org/ImageObject\"\n      >\n        <img\n          srcset=\"https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.600.jpeg 600w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.800.jpeg 800w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.1000.jpeg 1000w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.1200.jpeg 1200w,https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.82.1600.jpeg 1600w\"\n          src=\"https://www.aemcomponents.dev/content/core-components-examples/library/core-content/teaser/_jcr_content/root/responsivegrid/demo_1160408466/component/teaser.coreimg.jpeg\"\n          loading=\"lazy\"\n          class=\"cmp-image__image\"\n          itemprop=\"contentUrl\"\n          width=\"850\"\n          height=\"509\"\n          alt=\"Lava flowing into the ocean\"\n          title=\"Lava flowing into the ocean\"\n        />\n        <meta itemprop=\"caption\" content=\"Lava flowing into the ocean\" />\n      </div>\n    </div>\n  </div>\n</div>";
},"useData":true});

/***/ }),

/***/ "./src/main/webpack/pages/home/doc/home.stories.js":
/*!*********************************************************!*\
  !*** ./src/main/webpack/pages/home/doc/home.stories.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Primary: function() { return /* binding */ Primary; },
/* harmony export */   __namedExportsOrder: function() { return /* binding */ __namedExportsOrder; }
/* harmony export */ });
/* harmony import */ var handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
/* harmony import */ var handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_header_header_hbs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../components/header/header.hbs */ "./src/main/webpack/components/header/header.hbs");
/* harmony import */ var _components_header_header_hbs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_components_header_header_hbs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_components_breadcrumb_standard_hbs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../core-components/breadcrumb/standard.hbs */ "./src/main/webpack/core-components/breadcrumb/standard.hbs");
/* harmony import */ var _core_components_breadcrumb_standard_hbs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_components_breadcrumb_standard_hbs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _core_components_carousel_image_slides_hbs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core-components/carousel/image-slides.hbs */ "./src/main/webpack/core-components/carousel/image-slides.hbs");
/* harmony import */ var _core_components_carousel_image_slides_hbs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_core_components_carousel_image_slides_hbs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core-components/teaser/with-image.hbs */ "./src/main/webpack/core-components/teaser/with-image.hbs");
/* harmony import */ var _core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_cardgroup_cardgroup_hbs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../components/cardgroup/cardgroup.hbs */ "./src/main/webpack/components/cardgroup/cardgroup.hbs");
/* harmony import */ var _components_cardgroup_cardgroup_hbs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_components_cardgroup_cardgroup_hbs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_footer_footer_hbs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../components/footer/footer.hbs */ "./src/main/webpack/components/footer/footer.hbs");
/* harmony import */ var _components_footer_footer_hbs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_components_footer_footer_hbs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _home_hbs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../home.hbs */ "./src/main/webpack/pages/home/home.hbs");
/* harmony import */ var _home_hbs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_home_hbs__WEBPACK_IMPORTED_MODULE_7__);
var _excluded = ["label"];
function _objectWithoutProperties(e, t) {
  if (null == e) return {};
  var o,
    r,
    i = _objectWithoutPropertiesLoose(e, t);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
  }
  return i;
}
function _objectWithoutPropertiesLoose(r, e) {
  if (null == r) return {};
  var t = {};
  for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
    if (-1 !== e.indexOf(n)) continue;
    t[n] = r[n];
  }
  return t;
}









// Register all partials
handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('Header', (_components_header_header_hbs__WEBPACK_IMPORTED_MODULE_1___default()));
handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('Breadcrumb', (_core_components_breadcrumb_standard_hbs__WEBPACK_IMPORTED_MODULE_2___default()));
handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('Carousel', (_core_components_carousel_image_slides_hbs__WEBPACK_IMPORTED_MODULE_3___default()));
handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('Footer', (_components_footer_footer_hbs__WEBPACK_IMPORTED_MODULE_6___default()));
handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('CardGroup', (_components_cardgroup_cardgroup_hbs__WEBPACK_IMPORTED_MODULE_5___default()));
handlebars_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().registerPartial('TeaserWithImage', (_core_components_teaser_with_image_hbs__WEBPACK_IMPORTED_MODULE_4___default()));

// import '../../../site/main.scss';

/* harmony default export */ __webpack_exports__["default"] = ({
  title: 'Pages/Home',
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {}
});
var TemplateHome = function TemplateHome(_ref) {
  var label = _ref.label,
    args = _objectWithoutProperties(_ref, _excluded);
  return _home_hbs__WEBPACK_IMPORTED_MODULE_7___default()();
};
var Primary = TemplateHome.bind();
Primary.parameters = {
  tags: ['visual'] // Add visual tag to enable visual testing
};
;
const __namedExportsOrder = ["Primary"];
Primary.parameters = {
  ...Primary.parameters,
  docs: {
    ...Primary.parameters?.docs,
    source: {
      originalSource: "({\n  label,\n  ...args\n}) => Home()",
      ...Primary.parameters?.docs?.source
    }
  }
};

/***/ }),

/***/ "./src/main/webpack/pages/home/home.hbs":
/*!**********************************************!*\
  !*** ./src/main/webpack/pages/home/home.hbs ***!
  \**********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var Handlebars = __webpack_require__(/*! ../../../../../node_modules/handlebars/runtime.js */ "./node_modules/handlebars/runtime.js");
function __default(obj) { return obj && (obj.__esModule ? obj["default"] : obj); }
module.exports = (Handlebars["default"] || Handlebars).template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<div class=\"home\"> \n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"Header"),depth0,{"name":"Header","data":data,"helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + ((stack1 = container.invokePartial(lookupProperty(partials,"Breadcrumb"),depth0,{"name":"Breadcrumb","data":data,"helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + ((stack1 = container.invokePartial(lookupProperty(partials,"Carousel"),depth0,{"name":"Carousel","data":data,"helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + ((stack1 = container.invokePartial(lookupProperty(partials,"CardGroup"),depth0,{"name":"CardGroup","data":data,"helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + ((stack1 = container.invokePartial(lookupProperty(partials,"Footer"),depth0,{"name":"Footer","data":data,"helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "</div>";
},"usePartial":true,"useData":true});

/***/ })

}]);
//# sourceMappingURL=main-webpack-pages-home-doc-home-stories.iframe.bundle.js.map